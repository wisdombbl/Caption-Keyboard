package com.captionkeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 20, 24)
    private val panel = Color.rgb(48, 52, 61)
    private val white = Color.WHITE
    private lateinit var editor: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "CAPTION MANAGER"
            textSize = 21f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        val help = TextView(this).apply {
            text = "Paste one caption per line. Your library stays on this phone and works offline."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 14)
        }
        editor = EditText(this).apply {
            setTextColor(white)
            setHintTextColor(Color.GRAY)
            hint = "Paste your captions here…"
            textSize = 16f
            gravity = Gravity.TOP or Gravity.START
            setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
            minLines = 10
            setText(CaptionStore.get(this@MainActivity).joinToString("\n"))
        }
        val save = button("SAVE CAPTIONS")
        save.setOnClickListener {
            val lines = editor.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
            CaptionStore.save(this, lines)
            Toast.makeText(this, "${lines.size} captions saved", Toast.LENGTH_SHORT).show()
        }
        val enable = button("1. ENABLE KEYBOARD")
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        val choose = button("2. SELECT CAPTION KEYBOARD")
        choose.setOnClickListener {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        root.addView(title)
        root.addView(help)
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(save)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
    }

    private fun button(label: String) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(white)
        setBackgroundColor(Color.rgb(76, 82, 95))
        isAllCaps = false
        val p = LinearLayout.LayoutParams(-1, 54)
        p.topMargin = 10
        layoutParams = p
    }
}
