package com.captionkeyboard

import android.inputmethodservice.InputMethodService
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class CaptionImeService : InputMethodService() {
    private val bg = Color.rgb(25, 28, 34)
    private val buttonBg = Color.rgb(83, 89, 103)
    private val white = Color.WHITE
    private val copied = mutableSetOf<Int>()
    private lateinit var listBox: LinearLayout

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        copied.clear()
        if (::listBox.isInitialized) renderCaptions()
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 6)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = false }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(actionButton("⚙", 0.8f) {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        actions.addView(actionButton("SPACE", 3.5f) { currentInputConnection?.commitText(" ", 1) })
        actions.addView(actionButton("⌫", 0.8f) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        })
        actions.addView(actionButton("↵", 0.8f) {
            val ic = currentInputConnection
            if (ic != null) {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_UNSPECIFIED
                if (action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_GO ||
                    action == EditorInfo.IME_ACTION_DONE || action == EditorInfo.IME_ACTION_SEARCH) {
                    ic.performEditorAction(action)
                } else ic.commitText("\n", 1)
            }
        })
        root.addView(actions)
        renderCaptions()
        return root
    }

    private fun renderCaptions() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val captions = CaptionStore.get(this)
        if (captions.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No captions yet. Open Caption Manager to add captions."
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(12, 22, 12, 22)
            }
            listBox.addView(empty)
        } else {
            captions.forEachIndexed { index, caption ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(4, 3, 4, 3)
                }
                val label = TextView(this).apply {
                    text = "LINE ${index + 1}\n$caption"
                    setTextColor(white)
                    textSize = 14f
                    setPadding(12, 9, 8, 9)
                    maxLines = 4
                }
                val copy = TextView(this).apply {
                    text = if (copied.contains(index)) "COPIED ✓" else "INSERT"
                    setTextColor(white)
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(9, 12, 9, 12)
                    background = rounded(if (copied.contains(index)) Color.rgb(35, 112, 82) else Color.rgb(65, 72, 86))
                    setOnClickListener {
                        currentInputConnection?.commitText(caption, 1)
                        copied.add(index)
                        text = "COPIED ✓"
                        background = rounded(Color.rgb(35, 112, 82))
                    }
                }
                row.background = rounded(buttonBg)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = 5
                listBox.addView(row, lp)
                row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(copy)
            }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val shuffle = TextView(this).apply {
            text = "RESHUFFLE"
            styleControl()
            setOnClickListener {
                val values = CaptionStore.get(this@CaptionImeService).shuffled()
                CaptionStore.save(this@CaptionImeService, values)
                copied.clear()
                renderCaptions()
            }
        }
        val reset = TextView(this).apply {
            text = "RESET"
            styleControl()
            setOnClickListener { copied.clear(); renderCaptions() }
        }
        controls.addView(shuffle, LinearLayout.LayoutParams(0, 44, 1f))
        controls.addView(reset, LinearLayout.LayoutParams(0, 44, 1f))
        listBox.addView(controls)
    }

    private fun TextView.styleControl() {
        setTextColor(white)
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(Color.rgb(58, 64, 76))
        setPadding(8, 5, 8, 5)
    }

    private fun actionButton(label: String, weight: Float, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = if (label == "SPACE") 13f else 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(91, 98, 113))
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(0, 48, weight)
            lp.setMargins(3, 4, 3, 0)
            layoutParams = lp
        }
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = 8f
    }
}
