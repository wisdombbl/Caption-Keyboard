package com.captionkeyboard

import android.content.Context

object CaptionStore {
    private const val PREFS = "caption_keyboard_store"
    private const val KEY = "captions"

    fun get(context: Context): MutableList<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "") ?: ""
        return raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    }

    fun save(context: Context, captions: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, captions.joinToString("\n")).apply()
    }
}
