package com.example.captionkeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("CaptionPrefs", Context.MODE_PRIVATE)
        val etCaptions = findViewById<EditText>(R.id.etCaptions)
        val btnLoadLines = findViewById<Button>(R.id.btnLoadLines)
        val btnEnableKb = findViewById<Button>(R.id.btnEnableKb)
        val btnSwitchKb = findViewById<Button>(R.id.btnSwitchKb)

        etCaptions.setText(prefs.getString("raw_text", ""))

        btnEnableKb.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        btnSwitchKb.setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        btnLoadLines.setOnClickListener {
            val raw = etCaptions.text.toString()
            val captions = raw.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toList()

            val jsonArray = JSONArray()
            captions.forEach { jsonArray.put(it) }

            prefs.edit()
                .putString("raw_text", raw)
                .putString("saved_lines", jsonArray.toString())
                .putString("copied_indices", "[]")
                .apply()

            Toast.makeText(
                this,
                "Loaded ${captions.size} captions to keyboard",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
