package com.example.captionkeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import org.json.JSONArray

class CaptionKeyboardService : InputMethodService() {

    private val lines: MutableList<String> = mutableListOf()
    private val copiedSet: MutableSet<Int> = mutableSetOf()
    private lateinit var adapter: CaptionAdapter

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)
        val listView = view.findViewById<ListView>(R.id.lvCaptions)
        val btnReshuffle = view.findViewById<Button>(R.id.btnKbReshuffle)
        val btnReset = view.findViewById<Button>(R.id.btnKbReset)
        val btnSwitch = view.findViewById<Button>(R.id.btnKbSwitch)

        loadFromPrefs()
        adapter = CaptionAdapter()
        listView.adapter = adapter

        btnReshuffle.setOnClickListener {
            lines.shuffle()
            copiedSet.clear()
            saveState()
            adapter.notifyDataSetChanged()
        }

        btnReset.setOnClickListener {
            copiedSet.clear()
            saveState()
            adapter.notifyDataSetChanged()
        }

        btnSwitch.setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        return view
    }

    override fun onStartInputView(
        info: android.view.inputmethod.EditorInfo?,
        restarting: Boolean
    ) {
        super.onStartInputView(info, restarting)
        loadFromPrefs()
        if (::adapter.isInitialized) {
            adapter.notifyDataSetChanged()
        }
    }

    private fun loadFromPrefs() {
        val prefs = getSharedPreferences("CaptionPrefs", Context.MODE_PRIVATE)
        val jsonStr = prefs.getString("saved_lines", "[]") ?: "[]"
        val copiedStr = prefs.getString("copied_indices", "[]") ?: "[]"

        lines.clear()
        val arr = JSONArray(jsonStr)
        for (i in 0 until arr.length()) {
            lines.add(arr.getString(i))
        }

        copiedSet.clear()
        val copiedArray = JSONArray(copiedStr)
        for (i in 0 until copiedArray.length()) {
            copiedSet.add(copiedArray.getInt(i))
        }
    }

    private fun saveState() {
        val prefs = getSharedPreferences("CaptionPrefs", Context.MODE_PRIVATE)
        val linesArray = JSONArray()
        lines.forEach { linesArray.put(it) }

        val copiedArray = JSONArray()
        copiedSet.forEach { copiedArray.put(it) }

        prefs.edit()
            .putString("saved_lines", linesArray.toString())
            .putString("copied_indices", copiedArray.toString())
            .apply()
    }

    private inner class CaptionAdapter : BaseAdapter() {
        override fun getCount(): Int = lines.size

        override fun getItem(position: Int): String = lines[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?
        ): View {
            val row = convertView ?: LayoutInflater.from(this@CaptionKeyboardService)
                .inflate(R.layout.item_caption, parent, false)

            val tvText = row.findViewById<TextView>(R.id.tvCaptionText)
            val btnCopy = row.findViewById<Button>(R.id.btnCopyLine)

            val caption = lines[position]
            val isCopied = copiedSet.contains(position)

            tvText.text = caption
            if (isCopied) {
                btnCopy.text = "COPIED ✓"
                btnCopy.setBackgroundColor(Color.parseColor("#2E7D32"))
            } else {
                btnCopy.text = "LINE ${position + 1}"
                btnCopy.setBackgroundColor(Color.parseColor("#1976D2"))
            }

            btnCopy.setOnClickListener {
                currentInputConnection?.commitText(caption, 1)

                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE)
                    as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Caption", caption))

                copiedSet.add(position)
                saveState()
                notifyDataSetChanged()
            }

            return row
        }
    }
}
